package models

import "gorm.io/gorm"

type Document struct {
	gorm.Model
	Title       string `gorm:"not null"`
	SheetsCount int    `gorm:"check:sheets_count>0"` // Количество листов 
	FolderID    *uint  
	Folder      Folder // Связь с папкой
}
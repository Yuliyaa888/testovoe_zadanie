package models

import "gorm.io/gorm"

type Folder struct {
	gorm.Model
	Name        string `gorm:"not null"`
	TotalSheets int    `gorm:"default:480;not null"` // Всего листов (константа)
	UsedSheets  int    `gorm:"default:0;not null"`   // Занято листов (обновляется)
}
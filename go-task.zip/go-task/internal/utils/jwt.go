package utils

import (
	"time"
	"github.com/golang-jwt/jwt/v5"
)

// Access и Refresh токены для пользователя
func GenerateTokens(userID uint, accessSecret, refreshSecret string) (string, string, error) {
	accessToken := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"userID": userID,
		"exp":    time.Now().Add(time.Hour * 1).Unix(), 
		"type":   "access",
	})

	refreshToken := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"userID": userID,
		"exp":    time.Now().Add(time.Hour * 24 * 7).Unix(), 
		"type":   "refresh",
	})

	// Подписывание токенов секретными ключами
	accessString, err := accessToken.SignedString([]byte(accessSecret))
	if err != nil {
		return "", "", err
	}

	refreshString, err := refreshToken.SignedString([]byte(refreshSecret))
	if err != nil {
		return "", "", err
	}

	return accessString, refreshString, nil
}
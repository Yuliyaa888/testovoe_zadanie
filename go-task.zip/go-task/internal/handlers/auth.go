package handlers

import (
	"encoding/json"
	"fmt"
	"net/http"
	"go-task/internal/config"
	"go-task/internal/models"
	"go-task/internal/utils"
	"github.com/go-chi/chi/v5"
	"gorm.io/gorm"
)

// Данные для регистрации
type RegisterRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

// Ответ при успешной регистрации/логине
type AuthResponse struct {
	AccessToken  string `json:"access_token"`
	RefreshToken string `json:"refresh_token"`
}

type UpdateDocumentRequest struct {
	Title       *string `json:"title"`        
	SheetsCount *int    `json:"sheets_count"`  
	FolderID    *uint   `json:"folder_id"`    
}

type CreateDocumentRequest struct {
	Title       string `json:"title"`
	SheetsCount int    `json:"sheets_count"`
	FolderID    *uint  `json:"folder_id"` 
}

type DocumentResponse struct {
	ID          uint   `json:"id"`
	Title       string `json:"title"`
	SheetsCount int    `json:"sheets_count"`
	FolderID    *uint  `json:"folder_id"`
}


func Register(cfg *config.Config, db *gorm.DB) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var req RegisterRequest
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusBadRequest)
			json.NewEncoder(w).Encode(map[string]string{
				"error": "Invalid JSON",
			})
			return
		}

		hashedPassword, err := utils.HashPassword(req.Password)
		if err != nil {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusInternalServerError)
			json.NewEncoder(w).Encode(map[string]string{
				"error": "Error creating user",
			})
			return
		}

		user := models.User{
			Email:    req.Email,
			Password: hashedPassword,
		}

		result := db.Create(&user)
		if result.Error != nil {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusBadRequest)
			json.NewEncoder(w).Encode(map[string]string{
				"error": "User with this email already exists",
			})
			return
		}

		accessToken, refreshToken, err := utils.GenerateTokens(user.ID, cfg.JWT.AccessSecret, cfg.JWT.RefreshSecret)
		if err != nil {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusInternalServerError)
			json.NewEncoder(w).Encode(map[string]string{
				"error": "Error generating tokens",
			})
			return
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(AuthResponse{
			AccessToken:  accessToken,
			RefreshToken: refreshToken,
		})
	}
}

func Login(cfg *config.Config, db *gorm.DB) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var req RegisterRequest
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusBadRequest)
			json.NewEncoder(w).Encode(map[string]string{"error": "Invalid JSON"})
			return
		}

		var user models.User
		result := db.Where("email = ?", req.Email).First(&user)
		if result.Error != nil {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusUnauthorized)
			json.NewEncoder(w).Encode(map[string]string{"error": "Invalid credentials"})
			return
		}

		if !utils.CheckPasswordHash(req.Password, user.Password) {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusUnauthorized)
			json.NewEncoder(w).Encode(map[string]string{"error": "Invalid credentials"})
			return
		}

		accessToken, refreshToken, err := utils.GenerateTokens(user.ID, cfg.JWT.AccessSecret, cfg.JWT.RefreshSecret)
		if err != nil {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusInternalServerError)
			json.NewEncoder(w).Encode(map[string]string{"error": "Error generating tokens"})
			return
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(AuthResponse{
			AccessToken:  accessToken,
			RefreshToken: refreshToken,
		})
	}
}

func CreateDocument(db *gorm.DB) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var req CreateDocumentRequest
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusBadRequest)
			json.NewEncoder(w).Encode(map[string]string{"error": "Invalid JSON"})
			return
		}

		if req.SheetsCount <= 0 {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusBadRequest)
			json.NewEncoder(w).Encode(map[string]string{"error": "Sheets count must be positive"})
			return
		}

		if req.FolderID != nil {
			var folder models.Folder
			result := db.First(&folder, *req.FolderID)
			if result.Error != nil {
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusBadRequest)
				json.NewEncoder(w).Encode(map[string]string{"error": "Folder not found"})
				return
			}

			if folder.UsedSheets+req.SheetsCount > folder.TotalSheets {
				w.Header().Set("Content-Type", "application/json")
				w.WriteHeader(http.StatusBadRequest)
				json.NewEncoder(w).Encode(map[string]string{
					"error": fmt.Sprintf("Not enough space in folder. Available: %d, required: %d", 
						folder.TotalSheets-folder.UsedSheets, req.SheetsCount),
				})
				return
			}

			db.Model(&folder).Update("used_sheets", folder.UsedSheets+req.SheetsCount)
		}

		document := models.Document{
			Title:       req.Title,
			SheetsCount: req.SheetsCount,
			FolderID:    req.FolderID,
		}

		result := db.Create(&document)
		if result.Error != nil {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusInternalServerError)
			json.NewEncoder(w).Encode(map[string]string{"error": "Error creating document"})
			return
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(DocumentResponse{
			ID:          document.ID,
			Title:       document.Title,
			SheetsCount: document.SheetsCount,
			FolderID:    document.FolderID,
		})
	}
}

func UpdateDocument(db *gorm.DB) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		documentID := chi.URLParam(r, "id")
		if documentID == "" {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusBadRequest)
			json.NewEncoder(w).Encode(map[string]string{"error": "Document ID required"})
			return
		}

		var req UpdateDocumentRequest
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusBadRequest)
			json.NewEncoder(w).Encode(map[string]string{"error": "Invalid JSON"})
			return
		}

		err := db.Transaction(func(tx *gorm.DB) error {
			var document models.Document
			if err := tx.First(&document, documentID).Error; err != nil {
				return fmt.Errorf("document not found")
			}

			oldFolderID := document.FolderID
			oldSheetsCount := document.SheetsCount

			updates := make(map[string]interface{})
			if req.Title != nil {
				updates["title"] = *req.Title
			}
			if req.SheetsCount != nil {
				if *req.SheetsCount <= 0 {
					return fmt.Errorf("sheets count must be positive")
				}
				updates["sheets_count"] = *req.SheetsCount
			}
			if req.FolderID != nil {
				updates["folder_id"] = *req.FolderID
			}

			newFolderID := req.FolderID
			
			if newFolderID != nil || req.SheetsCount != nil {
				newSheets := oldSheetsCount
				if req.SheetsCount != nil {
					newSheets = *req.SheetsCount
				}

				if oldFolderID != nil {
					var oldFolder models.Folder
					if err := tx.First(&oldFolder, *oldFolderID).Error; err != nil {
						return fmt.Errorf("old folder not found")
					}
					newUsedSheets := oldFolder.UsedSheets - oldSheetsCount
					if newUsedSheets < 0 {
						newUsedSheets = 0
					}
					if err := tx.Model(&oldFolder).Update("used_sheets", newUsedSheets).Error; err != nil {
						return err
					}
				}

				if newFolderID != nil {
					var newFolder models.Folder
					if err := tx.First(&newFolder, *newFolderID).Error; err != nil {
						return fmt.Errorf("new folder not found")
					}

					if newFolder.UsedSheets+newSheets > newFolder.TotalSheets {
						return fmt.Errorf("not enough space in new folder")
					}

					if err := tx.Model(&newFolder).Update("used_sheets", newFolder.UsedSheets+newSheets).Error; err != nil {
						return err
					}
				}
			}

			if err := tx.Model(&document).Updates(updates).Error; err != nil {
				return err
			}

			return nil
		})

		if err != nil {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusBadRequest)
			json.NewEncoder(w).Encode(map[string]string{"error": err.Error()})
			return
		}

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]string{"message": "Document updated successfully"})
	}
}
package main

import (
	"fmt"
	"log"
	"net/http"
	"go-task/internal/config"
	"go-task/internal/database"
	"go-task/internal/handlers"
	"go-task/internal/handlers/middleware"
	"github.com/go-chi/cors"

	"github.com/go-chi/chi/v5"
)

func main() {
	cfg, err := config.LoadConfig(".")
	if err != nil {
		log.Fatalf("Не могу загрузить конфиг: %v", err)
	}

	db, err := database.InitPostgres(cfg)
	if err != nil {
		log.Fatalf("Не могу подключиться к БД: %v", err)
	}
	fmt.Println("Успешно подключились к PostgreSQL!")

    r := chi.NewRouter()
    
    r.Use(cors.Handler(cors.Options{
        AllowedOrigins:   []string{"*"},
        AllowedMethods:   []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
        AllowedHeaders:   []string{"Accept", "Authorization", "Content-Type", "X-CSRF-Token"},
        AllowCredentials: true,
        MaxAge:           300,
    }))

	r.Post("/register", handlers.Register(cfg, db))
	r.Post("/login", handlers.Login(cfg, db))

	r.Group(func(r chi.Router) {
		r.Use(middleware.AuthRequired(cfg.JWT.AccessSecret))
		r.Post("/documents", handlers.CreateDocument(db))
		r.Put("/documents/{id}", handlers.UpdateDocument(db))
	})

	serverAddr := cfg.Server.Port
	fmt.Printf("Сервер запущен на порту %s\n", serverAddr)
	log.Fatal(http.ListenAndServe(serverAddr, r))
}